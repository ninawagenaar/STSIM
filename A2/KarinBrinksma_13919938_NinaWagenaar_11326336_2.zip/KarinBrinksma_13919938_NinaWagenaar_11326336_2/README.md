**Approximating the average waiting times in queueing systems using Discrete Event Simulation**

This repository contains the code of the second assignment for the course Stochastic Simulation as the UvA and is made by
Kaat Brinksma and Nina Hagelaar. The implementation is in python 3.

To run the experiments run the experiment.py file
